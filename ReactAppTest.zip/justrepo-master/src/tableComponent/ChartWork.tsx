import { useState, useEffect } from "react";
import { EditOutlined, DeleteOutlined } from "@ant-design/icons";
import { Table, Modal, Input, Button } from "antd";

function ChartWork() {

    return (
        <div className="App">
            ChartWork
        </div>
    );
}

export default ChartWork;
