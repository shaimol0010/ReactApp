import { useState, useEffect } from "react";
import { EditOutlined, DeleteOutlined } from "@ant-design/icons";
import { Table, Modal, Input, Button } from "antd";
import AddEmployee from "./AddEmployee";
import ChartWork from './ChartWork';
import { descending } from "d3";

function TableWork() {
    // initialize hooks
    const [isEditing, setIsEditing] = useState(false);
    const [editingEmployee, setEditingEmployee] = useState<User | null>(null);
    const [users, setUsers] = useState<User[]>([]);
    const [page, setPage] = useState(1)
    const [pageSize, setPageSize] = useState(10)
    const [error, setError] = useState({});

    //interface
    interface User {
        userId: number;
        id: number;
        title: string;
        completed: boolean;
    }
    //columns for table
    const columns = [
        {
            title: 'ID',
            dataIndex: 'id',
            key: 'id',
            sorter: (record1: User, record2: User) => { return record1.id > record2.id ? 1 : -1 },
            // sortDirections:['descend'],
        },
        {
            title: 'USERID',
            dataIndex: 'userId',
            key: 'userId',
        },
        {
            title: 'TITLE',
            dataIndex: 'title',
            key: 'title',
        },

        // {
        //     key: 'completed',
        //     title: 'COMPLETED',
        //     dataIndex: 'completed',
        // },
        {
            key: "actions",
            title: "Actions",
            render: (record: User) => {
                return (
                    <>
                        <EditOutlined
                            onClick={() => {
                                onEditEmployee(record);
                            }}
                        />
                        <DeleteOutlined
                            onClick={() => {
                                onDeleteEmployee(record);
                            }}
                            style={{ color: "red", marginLeft: 12 }}
                        />
                    </>
                );
            },
        },
    ];

    //Delete function for delete a record
    const onDeleteEmployee = (record: User) => {
        Modal.confirm({
            title: "Are you sure, you want to delete this Employee record?",
            okText: "Yes",
            okType: "danger",
            onOk: () => {
                setUsers((pre: any) => {
                    return pre.filter((user: User) => user.id !== record.id);
                });
            },
        });
    };


    //Edit function for Edit a record
    const onEditEmployee = (record: User) => {
        setIsEditing(true);
        setEditingEmployee({ ...record });
    };
    const resetEditing = () => {
        setIsEditing(false);
        setEditingEmployee(null);
    };

    const handleCallBack = (childData: User): void => {

        console.log("Data Employee", childData);
        const newUser=[...users,childData];
        setUsers(newUser);


    }

    //Get Api call function using useEffect hook
    useEffect(() => {
        const axios = require("axios");
        const options = {
            method: "GET",
            url: "https://jsonplaceholder.typicode.com/todos",
        };

        axios
            .request(options)
            .then(function (response: { data: any }) {
                console.log("setting data work", response.data);

                setUsers(response.data);
            })
            .catch(function (error: any) {
                console.error(error);
            });
    }, []);
    return (
        <div className="App">
            {/* <ChartWork/> */}
            <AddEmployee parentCallBack={handleCallBack} />

            <Table
                dataSource={users}
                columns={columns}
                pagination={{
                    current: page,
                    pageSize: pageSize,
                    total: 100,
                    onChange: (page, pageSize) => {
                        setPage(page);
                        setPageSize(pageSize)
                    }
                }}
            />
            <Modal
                title="Edit Employee"
                visible={isEditing}
                okText="Save"
                onCancel={() => {
                    resetEditing();
                }}
                onOk={() => {
                    setUsers((pre: any) => {
                        return pre.map((user: User) => {
                            if (user.id === (editingEmployee && editingEmployee.id)) {
                                return editingEmployee;
                            } else {
                                return user;
                            }
                        });
                    });
                    resetEditing();
                }}
            >
                <Input
                    value={editingEmployee?.userId}
                    onChange={(e) => {
                        setEditingEmployee((pre: any) => {
                            return { ...pre, userId: e.target.value };
                        });
                    }}
                />
                <Input
                    value={editingEmployee?.title}
                    onChange={(e) => {
                        setEditingEmployee((pre: any) => {
                            return { ...pre, title: e.target.value };
                        });
                    }}
                />
            </Modal>
        </div>
    );
}

export default TableWork;
