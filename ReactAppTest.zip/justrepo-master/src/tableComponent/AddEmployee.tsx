import { useState, useEffect } from "react";
import { EditOutlined, DeleteOutlined } from "@ant-design/icons";
import { Form, Input, InputNumber, Button } from 'antd';

const layout = {
    labelCol: {
        span: 4,
    },
    wrapperCol: {
        span: 16,
    },
};

interface User {
    userId: number;
    id: number;
    title: string;
    completed: boolean;
}
interface functionProps {
    parentCallBack(user: User): void;
}
const AddEmployee: React.FC<functionProps> = ({ parentCallBack }) => {

    const [componentSize, setComponentSize] = useState('default');

    const onFinish = (values: User) => {
        console.log(values);
        parentCallBack(values);
        alert("Employee Details added successfully");
    };

    return (
        <Form {...layout} name="nest-messages" onFinish={onFinish}>
            <Form.Item
                name={['user', 'userId']}
                label="USER ID"
            >
                <Input />
            </Form.Item>

            <Form.Item
                name={['user', 'id']}
                label="ID"
            >
                <Input />
            </Form.Item>


            <Form.Item
                name={['user', 'title']}
                label="TITLE"
                rules={[
                    {
                        type: 'string',
                    },
                ]}
            >
                <Input />
            </Form.Item>

            {/* <Form.Item
                name={['user', 'completed']}
                label="Completed"
                rules={[
                    {
                        type: 'string',
                    },
                ]}
            >
                <Input />
            </Form.Item> */}

            <Form.Item wrapperCol={{ ...layout.wrapperCol, offset: 4 }}>
                <Button type="primary" htmlType="submit">
                    SAVE
                </Button>
            </Form.Item>
        </Form>

    );
}

export default AddEmployee;